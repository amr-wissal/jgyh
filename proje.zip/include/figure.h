#include <iostream>
#include <graphics.h>
#ifndef FIGURE_H
#define FIGURE_H
using namespace std;

class figure
{
    public:
        int x,y,a,b,couleur,type;
        figure(){}

        void set_droite(int x, int y,int a,int b, int couleur){ // initialiser droite
            this->x=x;
            this->y=y;
            this->a=a;
            this->b=b;
            this->couleur=couleur;
            if(a>0 && b==0)
                this->type = 1;
            else if(a==0 && b>0)
                this->type = 2;
            else if(a>0 && b!=0)
                this->type = 3;
            else
                cout << "Les dimensions sont incorrectes";
        }
        void set_cercle(int x, int y,int a, int couleur){ // initialiser cercle
            this->x=x;
            this->y=y;
            this->a=a;
            this->couleur=couleur;
            if(a>0)
                this->type = 4;
            else
                cout << "Le diam�tre doit �tre positif";
        }
        void set_rectangle(int x, int y,int a,int b, int couleur){ // initialiser rectangle
            this->x=x;
            this->y=y;
            this->a=a;
            this->b=b;
            this->couleur=couleur;
            if(a>0 && b>0)
                this->type = 5;
            else
                cout << "Les dimensions sont incorrectes";
        }
        void set_croix(int x, int y,int a,int b, int couleur){ // initialiser croix
            this->x=x;
            this->y=y;
            this->a=a;
            this->b=b;
            this->couleur=couleur;
            if(a>0 && b>0)
                this->type = 6;
            else
                cout << "Les dimensions sont incorrectes";
        }
        void set_triangle(int x, int y,int a,int b, int couleur){ // initialiser triangle
            this->x=x;
            this->y=y;
            this->a=a;
            this->b=b;
            this->couleur=couleur;
            if(a>0 && b>0)
                this->type = 7;
            else
                cout << "Les dimensions sont incorrectes";
        }
        int get_couleur(){ // return couleur
            return this->couleur;
        }
        int get_x_centre(){ // return x_centre
            return this->x;
        }
        int get_y_centre(){ // return y_centre
            return this->y;
        }

        int get_x_min(){ // return x_min
            if(this->type==2)
                return this->x;
            else
                return (this->x)-(this->a/2);

        }
        int get_x_max(){ // return x_max
            if(this->type==2)
                return this->x;
            else
                return (this->x)+(this->a/2);

        }
        int get_y_min(){ // return y_min
            if(this->type==1)
                return this->y;
            else if(this->type==7)
                return this->y-this->b*2/3;
            else
                return (this->y)-(this->b/2);

        }
        int get_y_max(){ // return y_max
            if(this->type==1)
                return this->y;
             else if(this->type==7)
                return this->y+this->b/3;
            else
                return (this->y)+(this->b/2);

        }
        void dessiner(){ // dessiner figures
            setcolor(this->couleur);

            switch(this->type){
            case 1:
                line(this->get_x_min(),this->get_y_min(),this->get_x_max(),this->get_y_max());
                break;
            case 2:
                line(this->get_x_min(),this->get_y_min(),this->get_x_max(),this->get_y_max());
                break;
            case 3:
                line(this->get_x_min(),this->get_y_min(),this->get_x_max(),this->get_y_max());
                break;
            case 4:
                circle(this->x,this->y,this->a/2);
                break;
            case 5:
                rectangle(this->get_x_min(),this->get_y_min(),this->get_x_max(),this->get_y_max());
                break;
            case 6:
                line(this->get_x_centre()-this->a/2,this->get_y_centre()-this->b/2, this->get_x_centre()+this->a/2,this->get_y_centre()+this->b/2);
                line(this->get_x_centre()-this->a/2,this->get_y_centre()+this->b/2, this->get_x_centre()+this->a/2,this->get_y_centre()-this->b/2);
                break;
            case 7:
                line(this->get_x_centre(),this->get_y_centre()-this->b*2/3, this->get_x_centre()-this->a/2,this->get_y_centre()+this->b/3);
                line(this->get_x_centre(),this->get_y_centre()-this->b*2/3, this->get_x_centre()+this->a/2,this->get_y_centre()+this->b/3);
                line(this->get_x_centre()-this->a/2,this->get_y_centre()+this->b/3, this->get_x_centre()+this->a/2,this->get_y_centre()+this->b/3);
                break;
            }

        }
        void deplacer(int dx, int dy){ // d�placer figures
            int oldCouleur=this->couleur;
            this->couleur=getbkcolor();
            this->dessiner();
            this->x += dx;
            this->y += dy;
            this->couleur=oldCouleur;
            this->dessiner();
        }

};

#endif // FIGURE_H
