#include <graphics.h>

#ifndef FENETRE_H
#define FENETRE_H


class Fenetre
{
    public:
        Fenetre();
        void ouvrir_graphique(){
            initwindow(400,400,"Bonhomme");
        }
        void fermer_graphique(void){
            closegraph(ALL_WINDOWS);
        }
        int get_couleur_fond(){
            return getbkcolor();
        }
        int get_x_max(){
            return getmaxx();
        }
        int get_y_max(){
            return getmaxy();
        }
        int get_couleur(int x, int y){
            return getpixel(x,y);
        }
        void allume(int x, int y, int c){
            putpixel(x,y,c);
        }

};

#endif // FENETRE_H
