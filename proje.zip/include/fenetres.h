#include <graphics.h>
#ifndef FENETRES_H
#define FENETRES_H


class fenetres
{
    public:
        int x,y;
        fenetres(){
            this->x=400;
            this->y=400;
        }

        void ouvrir_graphique(void){ // m�thode pour ouvrir le graphique
            initwindow(700, 700, "Bonhomme");
        }
        void fermer_graphique(void){ // m�thode pour fermer le graphique
            closegraph(ALL_WINDOWS);
        }
        int get_couleur_fond(void){ // m�thode pour d�fnir la couleur de l'arriere de plan
            return getbkcolor();
        }
        int get_x_max(void){ // return x_max
            return getmaxx();
        }
        int get_y_max(void){ // return y_max
            return getmaxy();
        }
        int get_couleur(int x, int y){ // return la couleur du point
            return getpixel(x,y);
        }
        void allume(int x, int y,int c){ // allumer la fenetre
            putpixel(x,y,c);
        }
};



#endif // FENETRES_H
