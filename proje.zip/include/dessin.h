#ifndef DESSIN_H
#define DESSIN_H
#include "figure.h"


class dessin
{
    public:
        int nbFig;
        figure tab [100];

        dessin(int nbFig){ // methode pour dessiner le bonhomme
            this->nbFig=nbFig;
        }

        void deplacer(int dx, int dy){ // methode pour deplacer le bonhomme
          for (int i=0;i<this->nbFig;i++) {
                this->tab[i].deplacer(dx,dy);

       }

        }

};

#endif // DESSIN_H
